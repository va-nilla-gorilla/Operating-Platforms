package com.gamingroom;
/*
 * Description: Project 1
 * Description:
 * Description:
 *
 * Class: CS-230-H4865
 * Author: Uriah L.Fadum
 * VM Author ID: N/A
 * Instructor: LaDawn Meade
 * Project One Due Date: March 21, 2021
 */

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

// Shows 80 Char width & also helps separate code while working on it
//---------------------------->80  CHAR WIDTH<--------------------------------//


/*******************************************************************\
 *  All code has been edited for readability, adding whitespace,   *
 *  proper indentation and applying style guidelines and best      *
 *  practices throughout                                           *
\*******************************************************************/

/*
 * REFERENCES:
 * 
 * Hands-On Design Patterns with Java
 * ISBN: 978-1-78980-977-0
 * 
 * Oracle Documentation:
 * 
 * https://docs.oracle.com/javase/8/docs/api/
 * 
 * Project One UML Diagram from Software Design Template (The Game Room)
 * 
 */

/**
 * A simple class to hold information about a team
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a team is
 * created.
 * </p>
 * @author coce@snhu.edu
 * @author uriah.fadum@snhu.edu
 */
public class Team extends Entity{
	
	long id;
	String name;
	// List to hold players
	private static List<Player> players = new ArrayList<Player>();
	
	/*
	 * Constructor with an identifier and name
	 */
	public Team(long id, String name) {
		super(id, name);
	}
	
	/**
	 * Construct a new player instance
	 * 
	 * @param name the unique name of the player
	 * @return the player instance (new or existing)
	 */
		public Player addPlayer(String name) {
		
			// a local team instance
			Player player = null;
					
			/**
			 * Iterator Design Pattern to look for existing player with same name
			 * (Hands-On Design Patterns with Java, CH. 3, pp. 76-78)
			 * (https://docs.oracle.com/javase/8/docs/api/java/util/Iterator.html)
			 */
			// Created Iterator variable w/ Java built in Iterator Utility
			Iterator<Player> playerListIterator = players.iterator();
			// While loop to iterate as long as there is data in list
			while (playerListIterator.hasNext()) {
				// Creating variable to return the next element in the iteration.
				Player instanceOfPlayer = playerListIterator.next();
				// if found, simply return the existing instance
				if (instanceOfPlayer.getName().equalsIgnoreCase(name)) {
					return instanceOfPlayer;
				}
			}
					
			// if not found, make a new player instance and add to list of players
			if (name == null) {
				players.add(player);
			}
		
			// return the new/existing game instance to the caller
			return player;
		}

	@Override
	public String toString() {
		return "Team [id=" + super.getId() + ", name=" + super.getName() + "]";
	}
}
