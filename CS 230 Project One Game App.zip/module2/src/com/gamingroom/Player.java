package com.gamingroom;
/*
 * Description: Project 1
 * Description:
 * Description:
 *
 * Class: CS-230-H4865
 * Author: Uriah L.Fadum
 * VM Author ID: N/A
 * Instructor: LaDawn Meade
 * Project One Due Date: March 21, 2021
 */

// Shows 80 Char width & also helps separate code while working on it
//---------------------------->80  CHAR WIDTH<--------------------------------//


/*******************************************************************\
 *  All code has been edited for readability, adding whitespace,   *
 *  proper indentation and applying style guidelines and best      *
 *  practices throughout                                           *
\*******************************************************************/

/*
 * REFERENCES:
 * 
 * Hands-On Design Patterns with Java
 * ISBN: 978-1-78980-977-0
 * 
 * Oracle Documentation:
 * 
 * https://docs.oracle.com/javase/8/docs/api/
 * 
 * Project One UML Diagram from Software Design Template (The Game Room)
 * 
 */

/**
 * A simple class to hold information about a player
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a player is
 * created.
 * </p>
 * @author coce@snhu.edu
 * @author uriah.fadum@snhu.edu
 */
public class Player extends Entity{

	/*
	 * Constructor with an identifier and name
	 */
	public Player(long id, String name) {
		super(id, name);
	}

	@Override
	public String toString() {
		return "Player [id=" + super.getId() + ", name=" + super.getName() + "]";
	}
}
