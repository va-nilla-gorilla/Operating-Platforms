package com.gamingroom;
/*
 * Description: Project 1
 * Description:
 * Description:
 *
 * Class: CS-230-H4865
 * Author: Uriah L.Fadum
 * VM Author ID: N/A
 * Instructor: LaDawn Meade
 * Project One Due Date: March 21, 2021
 */

// Shows 80 Char width & also helps separate code while working on it
//---------------------------->80  CHAR WIDTH<--------------------------------//


/*******************************************************************\
 *  All code has been edited for readability, adding whitespace,   *
 *  proper indentation and applying style guidelines and best      *
 *  practices throughout                                           *
\*******************************************************************/

/*
 * REFERENCES:
 * 
 * Hands-On Design Patterns with Java
 * ISBN: 978-1-78980-977-0
 * 
 * Oracle Documentation:
 * 
 * https://docs.oracle.com/javase/8/docs/api/
 * 
 * 
 */

/**
 * Application start-up program
 * 
 * @author coce@snhu.edu
 * @author uriah.fadum@snhu.edu
 */
public class ProgramDriver {
	
	/**
	 * The one-and-only main() method
	 * 
	 * @param args command line arguments
	 */
	public static void main(String[] args) {
		
		// Obtain reference to the singleton instance
		GameService service = GameService.getInstance(); 
		
		//System.out.println("\nAbout to test initializing game data...\n");
		
		// initialize with some game data
		Game game1 = service.addGame("Game #1");
		System.out.println(game1);
		Game game2 = service.addGame("Game #2");
		System.out.println(game2);
		
		// use another class to prove there is only one instance
		//SingletonTester tester = new SingletonTester();
		//tester.testSingleton();
	}
}
