package com.gamingroom;
/*
 * Description: Project 1
 * Description: 
 * Description:
 *
 * Class: CS-230-H4865
 * Author: Uriah L.Fadum
 * VM Author ID: N/A
 * Instructor: LaDawn Meade
 * Project One Due Date: March 21, 2021
 */

// Shows 80 Char width & also helps separate code while working on it
//---------------------------->80  CHAR WIDTH<--------------------------------//


/*******************************************************************\
 *  All code has been edited for readability, adding whitespace,   *
 *  proper indentation and applying style guidelines and best      *
 *  practices throughout                                           *
\*******************************************************************/

/*
 * REFERENCES:
 * 
 * Hands-On Design Patterns with Java
 * ISBN: 978-1-78980-977-0
 * 
 * Oracle Documentation:
 * 
 * https://docs.oracle.com/javase/8/docs/api/
 * https://docs.oracle.com/javase/8/docs/api/java/util/ArrayList.html#iterator--
 * 
 * Project One UML Diagram from Software Design Template (The Game Room)
 * 
 */

//---------------------------->80  CHAR WIDTH<--------------------------------//

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

//---------------------------->80  CHAR WIDTH<--------------------------------//

/**
 * A singleton service for the game engine
 * 
 * @author coce@snhu.edu
 * @author uriah.fadum@snhu.edu
 */
public class GameService {

	/**
	 * A list of the active games
	 */
	private static List<Game> games = new ArrayList<Game>();

	/*
	 * Holds the next game identifier
	 */
	private static long nextGameId = 1;
	
	/*
	 * Holds the next player identifier (Per Project One UML)
	 */
	private static long nextPlayerId = 1;
	
	/*
	 * Holds the next team identifier (Per Project One UML)
	 */
	private static long nextTeamId = 1;
	
	/*
	 * Created GameService instance object
	 * Per Singleton Design Pattern 
	 * (Hands-On Design Patterns with Java CH. 4, pp.139-141)
	 * NOTE: Edited per UML Diagram pp. 3 Domain Model "The Gaming Room UML Diagram"
	 */  
	private static GameService service;
	
	/*
	 * Private constructor so that class cannot be
	 * instantiated per Singleton Design Pattern
	 * (Hands-On Design Patterns with Java CH. 4, pp.139-141)
	 */ 
	private GameService() {
		
	}

	/*
	 * Public accessor method to verify & create game instance
	 * outside of singleton design
	 * (Hands-On Design Patterns with Java CH. 4, pp.139-141)
	 * NOTE: Edited per UML Diagram pp. 3 Domain Model "The Gaming Room UML Diagram"
	 */ 
	public static GameService getInstance() {
		// Condition to verify game service
		if (service == null) {
			//Create new game service if none exists
			service = new GameService();
			//Print creation statement
			System.out.println("Creating new game service...\n");
		}
		
		else {
			//Print existing service statement
			System.out.println("Game service already exists...\n");
			
		}	
		// return the service instance to the caller
		return service;
	}
	
//---------------------------->80  CHAR WIDTH<--------------------------------//
	
	/**
	 * Construct a new game instance
	 * 
	 * @param name the unique name of the game
	 * @return the game instance (new or existing)
	 */
	public Game addGame(String name) {

		// a local game instance
		Game game = null;
		
		/**
		 * Iterator Design Pattern to look for existing game with same name
		 * (Hands-On Design Patterns with Java, CH. 3, pp. 76-78)
		 * (https://docs.oracle.com/javase/8/docs/api/java/util/Iterator.html)
		 */
		// Created Iterator variable w/ Java built in Iterator Utility
		Iterator<Game> gameListIterator = games.iterator();
		// While loop to iterate as long as there is data in list
		while (gameListIterator.hasNext()) {
			// Creating variable to return the next element in the iteration.
			Game instanceOfGame = gameListIterator.next();
			// if found, simply return the existing instance
			if (instanceOfGame.getName().equalsIgnoreCase(name)) {
				return instanceOfGame;
			}
		}
		
		// if not found, make a new game instance and add to list of games
		if (game == null) {
			game = new Game(nextGameId++, name);
			games.add(game);
		}

		// return the new/existing game instance to the caller
		return game;
	}

//---------------------------->80  CHAR WIDTH<--------------------------------//	
	
	
	/**
	 * <p>
	 * Returns the game instance with the specified id.
	 * 
	 * </p>
	 * @param id unique identifier of game to search for
	 * @return requested game instance
	 */
	public Game getGame(long id) {
		// a local game instance
		Game game = null;		
		/**
		 * Iterator Design Pattern to look for existing game with same id
		 * (Hands-On Design Patterns with Java, CH. 3, pp. 76-78)
		 * (https://docs.oracle.com/javase/8/docs/api/java/util/Iterator.html)
		 */
		// Created Iterator variable w/ Java built in Iterator Utility
		Iterator<Game> gameListIterator = games.iterator();
		// While loop to iterate as long as there is data
		while (gameListIterator.hasNext()) {
			//Creating variable to return the next element in the iteration.
			Game instanceOfGame = gameListIterator.next();
			// if found, simply assign that instance to the local variable
			if (instanceOfGame.getId() == id) {
				game = instanceOfGame;
			}
		}
		// return the new/existing game instance to the caller
		return game;
	}
	
//---------------------------->80  CHAR WIDTH<--------------------------------//
	
	/**
	 * Returns the game instance with the specified name.
	 * 
	 * @param name unique name of game to search for
	 * @return requested game instance
	 */
	public Game getGame(String name) {

		// a local game instance
		Game game = null;
		
		/**
		 * Iterator to look for existing game with same name
		 * (Hands-On Design Patterns with Java, CH. 3, pp. 76-78)
		 * (https://docs.oracle.com/javase/8/docs/api/java/util/Iterator.html)
		 */
		// Created Iterator variable w/ Java built in Iterator Utility
		Iterator<Game> gameListIterator = games.iterator();
		// While loop to iterate as long as there is data
		while (gameListIterator.hasNext()) {
			//Creating variable to return the next element in the iteration. 
			Game instanceOfGame = gameListIterator.next();
			// if found, simply assign that instance to the local variable
			if (instanceOfGame.getName().equalsIgnoreCase(name)) {
				game = instanceOfGame;
			}
		}
		// return the new/existing game instance to the caller
		return game;
	}
	
//---------------------------->80  CHAR WIDTH<--------------------------------//
	
	/**
	 * Returns the number of games currently active
	 * 
	 * @return the number of games currently active
	 */
	public int getGameCount() {
		return games.size();
	}
	
//---------------------------->80  CHAR WIDTH<--------------------------------//
	
	/**
	 * Returns next player id
	 * Refer to Project One UML
	 * @return incremented player id
	 */
	public long getNextPlayerId() {
		return nextPlayerId++;
	}
	
//---------------------------->80  CHAR WIDTH<--------------------------------//
	
	/**
	 * Returns next team id
	 * Refer to Project One UML
	 * @return incremented team id 
	 */
	public long getNextTeamId() {
		return nextTeamId++;
	}
	
}
