package com.gamingroom;
/*
 * Description: Project 1
 * Description:
 * Description:
 *
 * Class: CS-230-H4865
 * Author: Uriah L.Fadum
 * VM Author ID: N/A
 * Instructor: LaDawn Meade
 * Project One Due Date: March 21, 2021
 */

// Shows 80 Char width & also helps separate code while working on it
//---------------------------->80  CHAR WIDTH<--------------------------------//


/*******************************************************************\
 *  All code has been edited for readability, adding whitespace,   *
 *  proper indentation and applying style guidelines and best      *
 *  practices throughout                                           *
\*******************************************************************/

/*
 * REFERENCES:
 * 
 * Hands-On Design Patterns with Java
 * ISBN: 978-1-78980-977-0
 * 
 * Oracle Documentation:
 * 
 * https://docs.oracle.com/javase/8/docs/api/
 * 
 * Other:
 * 
 * Project One UML Diagram from Software Design Template (The Game Room)
 * 
 */

/**
 * 
 * Entity Super Class 
 * 
 * 
 * @author uriah.fadum@snhu.edu
 */
public class Entity {
	// Private Attributes
	private long id;
	private String name;
	
	/**
	 * Private Default Constructor
	 * Per UML Diagram
	 */
	private Entity() {}
	
	
	/**
	 * User defined Constructor with parameters
	 * Per UML Diagram
	 */
	public Entity(long id, String name) {
		this.id = id;
		this.name = name;
	}

	/**
	 * @return the id
	 */
	public long getId() {
		return this.id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return this.name;
	}

	// Returning ID and Name as single string
	public String toString() {
		
		return "Game [id=" + this.id + ", name=" + this.name + "]";
	}
}
