package com.gamingroom;
/*
  * Description: Project 1
 * Description:
 * Description:
 *
 * Class: CS-230-H4865
 * Author: Uriah L.Fadum
 * VM Author ID: N/A
 * Instructor: LaDawn Meade
 * Project One Due Date: March 21, 2021
 */

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

// Shows 80 Char width & also helps separate code while working on it
//---------------------------->80  CHAR WIDTH<--------------------------------//


/*******************************************************************\
 *  All code has been edited for readability, adding whitespace,   *
 *  proper indentation and applying style guidelines and best      *
 *  practices throughout                                           *
\*******************************************************************/

/*
 * REFERENCES:
 * 
 * Hands-On Design Patterns with Java
 * ISBN: 978-1-78980-977-0
 * 
 * Oracle Documentation:
 * 
 * https://docs.oracle.com/javase/8/docs/api/
 * https://docs.oracle.com/javase/8/docs/api/java/util/ArrayList.html#iterator--
 * 
 * Project One UML Diagram from Software Design Template (The Game Room)
 * 
 */

/**
 * A simple class to hold information about a game
 * 
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a game is
 * created.
 * </p>
 * 
 * @author coce@snhu.edu
 * @author uriah.fadum@snhu.edu
 */
public class Game extends Entity {
	
	private static List<Team> teams = new ArrayList<Team>();
	
	/**
	 * Constructor with an identifier and name
	 */
	public Game(long id, String name) {
		super(id, name);
	}

//---------------------------->80  CHAR WIDTH<--------------------------------//
	
/**
 * Construct a new team instance
 * 
 * @param name the unique name of the team
 * @return the team instance (new or existing)
 */
	public Team addTeam(String name) {
	
		// a local team instance
		Team team = null;
				
		/**
		 * Iterator Design Pattern to look for existing team with same name
		 * (Hands-On Design Patterns with Java, CH. 3, pp. 76-78)
		 * (https://docs.oracle.com/javase/8/docs/api/java/util/Iterator.html)
		 */
		// Created Iterator variable w/ Java built in Iterator Utility
		Iterator<Team> teamListIterator = teams.iterator();
		// While loop to iterate as long as there is data in list
		while (teamListIterator.hasNext()) {
			// Creating variable to return the next element in the iteration.
			Team instanceOfTeam = teamListIterator.next();
			// if found, simply return the existing instance
			if (instanceOfTeam.getName().equalsIgnoreCase(name)) {
				return instanceOfTeam;
			}
		}
				
		// if not found, make a new team instance and add to list of teams
		if (name == null) {
			teams.add(team);
		}
	
		// return the new/existing game instance to the caller
		return team;
	}
	
	@Override
	public String toString() {
		
		return "Game [id=" + super.getId() + ", name=" + super.getName() + "]";
	}

}
